import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Play, RotateCcw } from "lucide-react";
import { cleanDNA, gcContent, primerTm } from "../lib/genetics";

const sig = (x: number) => 1 / (1 + Math.exp(-x));
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));

const POLYMERASES = {
  taq: { name: "Taq", rate: 1000, opt: 72, note: "about 1 kb per minute, no proofreading" },
  pfu: { name: "Pfu (high fidelity)", rate: 500, opt: 72, note: "about 0.5 kb per minute, proofreading" },
} as const;

export default function PCRSim() {
  const [fwd, setFwd] = useState("GGCTTGAACGTTAGCACCTCGG");
  const [rev, setRev] = useState("ATCACCACGGCTCCTTGCTTGC");
  const [ampLen, setAmpLen] = useState(500);
  const [tDen, setTDen] = useState(95);
  const [sDen, setSDen] = useState(30);
  const [tAn, setTAn] = useState(58);
  const [sAn, setSAn] = useState(30);
  const [tExt, setTExt] = useState(72);
  const [sExt, setSExt] = useState(30);
  const [cycles, setCycles] = useState(30);
  const [template, setTemplate] = useState(100);
  const [pol, setPol] = useState<keyof typeof POLYMERASES>("taq");
  const [cur, setCur] = useState<number | null>(null);
  const [anim, setAnim] = useState(false);

  useEffect(() => { setCur(null); }, [tDen, sDen, tAn, sAn, tExt, sExt, cycles, template, ampLen, pol, fwd, rev]);

  const f = cleanDNA(fwd), r = cleanDNA(rev);
  const tmF = primerTm(f), tmR = primerTm(r);
  const tmMin = Math.min(tmF, tmR);

  const model = useMemo(() => {
    const P = POLYMERASES[pol];
    const denat = sig((tDen - 91) / 1.5) * clamp(sDen / 10, 0, 1) * (tDen > 99 ? 0.85 : 1); // very hot kills enzyme activity over cycles
    const bind = sig((tmMin + 5 - tAn) / 2.5); // primers bind when annealing temp is not above Tm
    const specificity = sig((tAn - (tmMin - 6)) / 2); // low temperature allows mismatched priming
    const extComplete = clamp(((sExt / 60) * P.rate) / ampLen, 0, 1) * sig(-Math.abs(tExt - P.opt) / 5 + 2);
    const primerOk = f.length >= 15 && r.length >= 15 && Math.abs(tmF - tmR) <= 8;
    const eff = clamp(denat * bind * extComplete * (primerOk ? 0.97 : 0.5), 0, 0.98);
    const specEff = clamp(eff * specificity, 0, 0.98);
    const nonSpecEff = clamp(eff * (1 - specificity) * 1.1, 0, 0.98);
    const cap = 1e13; // reagent-limited plateau
    let target = template, off = 0;
    const series: { n: number; target: number; off: number }[] = [{ n: 0, target, off }];
    for (let c = 1; c <= cycles; c++) {
      const total = target + off;
      const crowd = Math.max(0, 1 - total / cap);
      target += target * specEff * crowd;
      off += (target * nonSpecEff * crowd) * 0.5 + off * nonSpecEff * crowd;
      series.push({ n: c, target, off });
    }
    return { eff, specEff, nonSpecEff, specificity, series, denat, bind, extComplete, primerOk };
  }, [tDen, sDen, tAn, sExt, tExt, tmMin, tmF, tmR, ampLen, pol, cycles, template, f.length, r.length]);

  const last = model.series[model.series.length - 1];
  const shown = cur === null ? last : model.series[clamp(cur, 0, model.series.length - 1)];
  const purity = shown.target + shown.off > 0 ? (shown.target / (shown.target + shown.off)) * 100 : 0;
  const total = cycles * (sDen + sAn + sExt) / 60;

  const run = () => {
    setAnim(true); setCur(0);
    let i = 0;
    const id = setInterval(() => {
      i++; setCur(i);
      if (i >= cycles) { clearInterval(id); setAnim(false); setTimeout(() => setCur(null), 200); }
    }, 140);
  };

  const maxLog = Math.max(1, Math.log10(Math.max(...model.series.map((s) => s.target + s.off), 10)));
  const W = 560, H = 190;
  const pts = (key: "target" | "off") =>
    model.series.map((s, i) => `${(i / Math.max(1, cycles)) * (W - 40) + 30},${H - 20 - (Math.log10(Math.max(1, s[key]) ) / maxLog) * (H - 40)}`).join(" ");

  // gel: band brightness follows log yield
  const band = (v: number) => clamp(Math.log10(Math.max(1, v)) / 12, 0, 1);

  const warnings: string[] = [];
  if (f.length < 15 || r.length < 15) warnings.push("Primers shorter than about 15 nt usually bind poorly and non-specifically.");
  if (Math.abs(tmF - tmR) > 5) warnings.push(`Primer Tm values differ by ${Math.abs(tmF - tmR).toFixed(1)} C. Aim for a difference of 3 C or less.`);
  if (tAn > tmMin + 2) warnings.push("Annealing temperature is above the lower primer Tm: primers struggle to bind, yield drops.");
  if (tAn < tmMin - 8) warnings.push("Annealing temperature is far below the Tm: extra non-specific bands are likely.");
  if (tDen < 92) warnings.push("Denaturation below about 92 C may leave template strands paired.");
  if (model.extComplete < 0.8) warnings.push(`Extension is too short for a ${ampLen} bp product with ${POLYMERASES[pol].name}. Add time or shorten the amplicon.`);
  if (gcContent(f) < 40 || gcContent(f) > 60 || gcContent(r) < 40 || gcContent(r) > 60) warnings.push("A primer GC content outside 40 to 60% can hurt priming.");

  const phase = ["Denaturation", "Annealing", "Extension"];
  return (
    <div className="grid lg:grid-cols-[320px_1fr] gap-5">
      <div className="card p-4 space-y-3">
        <h3 className="font-semibold">Reaction setup</h3>
        <div><label className="label" htmlFor="fwd">Forward primer (5' to 3')</label><input id="fwd" className="input seq" value={fwd} onChange={(e) => setFwd(e.target.value.toUpperCase())} /><p className="text-xs text-slate-500 mt-1">{f.length} nt, GC {gcContent(f).toFixed(0)}%, Tm {tmF.toFixed(1)} C</p></div>
        <div><label className="label" htmlFor="rev">Reverse primer (5' to 3')</label><input id="rev" className="input seq" value={rev} onChange={(e) => setRev(e.target.value.toUpperCase())} /><p className="text-xs text-slate-500 mt-1">{r.length} nt, GC {gcContent(r).toFixed(0)}%, Tm {tmR.toFixed(1)} C</p></div>
        <div><label className="label" htmlFor="pol">Polymerase</label>
          <select id="pol" className="input" value={pol} onChange={(e) => setPol(e.target.value as keyof typeof POLYMERASES)}>
            {Object.entries(POLYMERASES).map(([k, v]) => <option key={k} value={k}>{v.name}</option>)}
          </select><p className="text-xs text-slate-500 mt-1">{POLYMERASES[pol].note}</p></div>
        <Slider label="Amplicon length" v={ampLen} set={setAmpLen} min={100} max={3000} step={50} unit="bp" />
        <Slider label="Starting template copies" v={template} set={setTemplate} min={1} max={10000} unit="" />
        <h3 className="font-semibold pt-2">Thermal profile</h3>
        <Slider label="Denaturation temperature" v={tDen} set={setTDen} min={85} max={100} unit="C" />
        <Slider label="Denaturation time" v={sDen} set={setSDen} min={5} max={60} unit="s" />
        <Slider label="Annealing temperature" v={tAn} set={setTAn} min={40} max={72} unit="C" />
        <Slider label="Annealing time" v={sAn} set={setSAn} min={5} max={60} unit="s" />
        <Slider label="Extension temperature" v={tExt} set={setTExt} min={60} max={78} unit="C" />
        <Slider label="Extension time" v={sExt} set={setSExt} min={5} max={180} unit="s" />
        <Slider label="Cycles" v={cycles} set={setCycles} min={1} max={40} unit="" />
        <div className="flex gap-2 pt-1">
          <button className="btn btn-primary flex-1 justify-center" onClick={run} disabled={anim}><Play size={16} /> Run cycles</button>
          <button className="btn" onClick={() => { setCur(null); setAnim(false); }} aria-label="Reset view"><RotateCcw size={16} /></button>
        </div>
        <p className="text-xs text-slate-500">Run time about {total.toFixed(0)} min of cycling.</p>
      </div>

      <div className="space-y-4">
        <div className="grid sm:grid-cols-4 gap-3">
          {[
            ["Cycle", cur === null ? `${cycles}` : `${Math.min(cur, cycles)} / ${cycles}`],
            ["Per-cycle efficiency", `${(model.eff * 100).toFixed(0)}%`],
            ["Target copies", shown.target.toExponential(2)],
            ["Specificity of product", `${purity.toFixed(0)}%`],
          ].map(([k, v]) => (
            <div key={k} className="card p-3"><div className="text-xs text-slate-400">{k}</div><div className="text-lg font-mono text-cyan">{v}</div></div>
          ))}
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2">One cycle</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { n: 0, t: tDen, s: sDen, ok: model.denat, d: "Strands separate" },
              { n: 1, t: tAn, s: sAn, ok: model.bind, d: "Primers bind" },
              { n: 2, t: tExt, s: sExt, ok: model.extComplete, d: "Polymerase extends" },
            ].map((p) => (
              <div key={p.n} className="rounded-xl border border-line p-3">
                <div className="text-xs text-slate-400">{phase[p.n]}</div>
                <div className="font-mono">{p.t} C, {p.s} s</div>
                <svg viewBox="0 0 120 50" className="w-full mt-1" role="img" aria-label={`${phase[p.n]} diagram`}>
                  {p.n === 0 ? (<>
                    <motion.path d="M5 15 C 30 5, 50 25, 60 15" stroke="#06B6D4" strokeWidth="2.5" fill="none" animate={{ y: p.ok > .5 ? -6 : 0 }} transition={{ type: "spring" }} />
                    <motion.path d="M5 35 C 30 45, 50 25, 60 35" stroke="#8B5CF6" strokeWidth="2.5" fill="none" animate={{ y: p.ok > .5 ? 6 : 0 }} transition={{ type: "spring" }} />
                  </>) : (<>
                    <path d="M5 15 H115" stroke="#06B6D4" strokeWidth="2.5" /><path d="M5 40 H115" stroke="#8B5CF6" strokeWidth="2.5" />
                    <motion.rect x="12" y="19" width="26" height="6" rx="3" fill="#F59E0B" animate={{ opacity: p.n === 1 ? (p.ok > .5 ? 1 : .2) : 1 }} />
                    {p.n === 2 && <motion.rect x="38" y="19" height="6" rx="3" fill="#10B981" initial={{ width: 0 }} animate={{ width: 70 * p.ok }} />}
                  </>)}
                </svg>
                <div className="text-xs text-slate-500">{p.d}: {(p.ok * 100).toFixed(0)}% effective</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2">Amplification (log scale)</h3>
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Copies per cycle on a log scale">
            <line x1="30" y1={H - 20} x2={W - 10} y2={H - 20} stroke="#1E293B" /><line x1="30" y1="10" x2="30" y2={H - 20} stroke="#1E293B" />
            <polyline points={pts("target")} fill="none" stroke="#06B6D4" strokeWidth="2.5" />
            <polyline points={pts("off")} fill="none" stroke="#F59E0B" strokeWidth="2" strokeDasharray="4 3" />
            {cur !== null && <line x1={(Math.min(cur, cycles) / Math.max(1, cycles)) * (W - 40) + 30} x2={(Math.min(cur, cycles) / Math.max(1, cycles)) * (W - 40) + 30} y1="10" y2={H - 20} stroke="#8B5CF6" />}
            <text x="32" y="22" fill="#94a3b8" fontSize="10">log10 copies</text>
            <text x={W - 60} y={H - 6} fill="#94a3b8" fontSize="10">cycles</text>
          </svg>
          <div className="flex gap-4 text-xs text-slate-400"><span><span className="text-cyan">---</span> target amplicon</span><span><span className="text-amber">- -</span> non-specific product</span></div>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2">Gel preview (agarose)</h3>
          <div className="flex gap-6 items-end h-40 bg-[#0a0f1c] rounded-lg p-3 border border-line">
            <Lane label="Ladder" bands={[{ y: 15, o: 0.8 }, { y: 30, o: 0.8 }, { y: 48, o: 0.8 }, { y: 68, o: 0.8 }, { y: 90, o: 0.8 }]} />
            <Lane label="Your PCR" bands={[{ y: 90 - ((Math.log10(ampLen) - 2) / (Math.log10(3000) - 2)) * 78, o: band(shown.target) }, { y: 72, o: band(shown.off) * 0.9 }]} />
            <Lane label="No template" bands={[]} />
          </div>
          <p className="text-xs text-slate-500 mt-2">Bigger fragments run higher. The faint lower band stands for non-specific product.</p>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2">Interpretation</h3>
          {warnings.length === 0 ? <p className="text-sm text-bio">Good conditions: primers match, annealing is near the Tm, and extension is long enough.</p> :
            <ul className="text-sm space-y-1 list-disc pl-5 text-amber">{warnings.map((w) => <li key={w}>{w}</li>)}</ul>}
          <p className="text-xs text-slate-500 mt-3">Educational model: it shows how the parameters trade off, it is not a predictor of exact lab yields. Real optimization needs a gradient PCR and controls.</p>
        </div>
      </div>
    </div>
  );
}

function Slider({ label, v, set, min, max, step = 1, unit }: { label: string; v: number; set: (n: number) => void; min: number; max: number; step?: number; unit: string }) {
  return (
    <label className="block">
      <span className="flex justify-between text-xs text-slate-400"><span>{label}</span><span className="text-cyan font-mono">{v} {unit}</span></span>
      <input type="range" min={min} max={max} step={step} value={v} onChange={(e) => set(Number(e.target.value))} aria-label={label} />
    </label>
  );
}

function Lane({ label, bands }: { label: string; bands: { y: number; o: number }[] }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative w-14 h-32 rounded bg-black/40 border border-line">
        {bands.map((b, i) => <div key={i} className="absolute left-1 right-1 h-1.5 rounded bg-cyan" style={{ top: `${b.y}%`, opacity: Math.max(0.05, b.o) }} />)}
      </div>
      <span className="text-[10px] text-slate-400">{label}</span>
    </div>
  );
}
