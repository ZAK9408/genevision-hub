import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Scissors } from "lucide-react";
import { cleanDNA, gcContent, reverseComplement } from "../lib/genetics";

const DEFAULT_SEQ = "ATGGCTAGCAAGGGTGAAGAACTGTTCACCGGCGTGGTGCCCATCCTGGTCGAGCTGGACGGCGACGTAAACGGCCACAAGTTCAGC";

interface Site { strand: "+" | "-"; start: number; protospacer: string; pam: string; cut: number; mismatches: number[]; mm: number; seedMM: number }

function findSites(seq: string, grna: string): Site[] {
  const out: Site[] = [];
  const L = seq.length;
  for (const strand of ["+", "-"] as const) {
    const s = strand === "+" ? seq : reverseComplement(seq);
    for (let i = 0; i + 23 <= s.length; i++) {
      const proto = s.slice(i, i + 20), pam = s.slice(i + 20, i + 23);
      if (!/^[ACGT]GG$/.test(pam)) continue;
      const mismatches: number[] = [];
      for (let k = 0; k < 20; k++) if (grna[k] !== proto[k]) mismatches.push(k);
      const seedMM = mismatches.filter((k) => k >= 10).length;
      const cut = strand === "+" ? i + 17 : L - (i + 17);
      const start = strand === "+" ? i : L - (i + 23);
      out.push({ strand, start, protospacer: proto, pam, cut, mismatches, mm: mismatches.length, seedMM });
    }
  }
  return out;
}

function rng(seed: number) { let x = seed * 9301 + 49297; return () => { x = (x * 9301 + 49297) % 233280; return x / 233280; }; }

export default function CrisprSim() {
  const [seqIn, setSeqIn] = useState(DEFAULT_SEQ);
  const [grna, setGrna] = useState("");
  const [step, setStep] = useState(0);
  const [seed, setSeed] = useState(1);
  const [pathway, setPathway] = useState<"nhej" | "hdr">("nhej");
  const [donor, setDonor] = useState("GAATTC");
  const seq = cleanDNA(seqIn).slice(0, 240);

  const candidates = useMemo(() => {
    const a = findSites(seq, "N".repeat(20));
    return a.filter((s) => s.strand === "+" || true).map((s) => ({ ...s, gc: gcContent(s.protospacer) }));
  }, [seq]);

  const g = cleanDNA(grna);
  const valid = g.length === 20;
  const sites = useMemo(() => (valid ? findSites(seq, g).filter((s) => s.mm <= 4).sort((a, b) => a.mm - b.mm) : []), [seq, g, valid]);
  const primary = sites[0];
  const cleaves = (s: Site) => s.mm === 0 || (s.seedMM === 0 && s.mm <= 3);
  const cutSites = sites.filter(cleaves);
  const target = cutSites[0];

  const repair = useMemo(() => {
    if (!target) return null;
    const r = rng(seed);
    const cut = target.cut;
    if (pathway === "hdr") {
      const ins = cleanDNA(donor).slice(0, 60);
      const result = seq.slice(0, cut) + ins + seq.slice(cut);
      return { kind: "HDR", delta: ins.length, left: seq.slice(0, cut), mid: ins, right: seq.slice(cut), removed: "", result, label: `Precise insertion of ${ins.length} nt from the donor template` };
    }
    const roll = r();
    if (roll < 0.35) { const b = "ACGT"[Math.floor(r() * 4)]; return { kind: "NHEJ", delta: 1, left: seq.slice(0, cut), mid: b, right: seq.slice(cut), removed: "", result: seq.slice(0, cut) + b + seq.slice(cut), label: `+1 insertion (${b})` }; }
    const n = 1 + Math.floor(r() * 9);
    const st = Math.max(0, cut - Math.floor(n / 2));
    const en = Math.min(seq.length, st + n);
    return { kind: "NHEJ", delta: -(en - st), left: seq.slice(0, st), mid: "", right: seq.slice(en), removed: seq.slice(st, en), result: seq.slice(0, st) + seq.slice(en), label: `${en - st} bp deletion` };
  }, [target, seed, pathway, donor, seq]);

  const steps = ["Setup", "1. Binding and PAM scan", "2. R-loop and recognition", "3. Cleavage", "4. DNA repair"];

  const [hover, setHover] = useState<number | null>(null);
  const colorFor = (i: number): string => {
    if (!target || step < 1) return "";
    const off = target.strand === "+" ? i - target.start : (target.start + 22) - i; // index along protospacer+PAM, 0..22
    if (off < 0 || off > 22) return "";
    return off < 20 ? "text-mol font-bold" : "text-amber font-bold";
  };

  return (
    <div className="space-y-5">
      <div className="grid lg:grid-cols-2 gap-5">
        <div className="card p-4 space-y-3">
          <h3 className="font-semibold">1. Target DNA (coding strand, 5' to 3')</h3>
          <textarea className="input seq h-24" value={seqIn} onChange={(e) => { setSeqIn(e.target.value.toUpperCase()); setStep(0); }} aria-label="Target DNA sequence" />
          <p className="text-xs text-slate-500">{seq.length} nt (max 240). Only A, C, G, T are kept. SpCas9 needs an <span className="text-amber">NGG</span> PAM right after the 20-nt target on the same strand.</p>
          <h3 className="font-semibold pt-2">2. Choose a guide RNA (gRNA)</h3>
          <input className="input seq" value={grna} onChange={(e) => { setGrna(e.target.value.toUpperCase()); setStep(0); }} placeholder="20-nt spacer, DNA letters (e.g. from the list)" aria-label="gRNA spacer sequence" />
          <p className="text-xs text-slate-500">{g.length}/20 nt. GC {g.length ? gcContent(g).toFixed(0) : 0}%{g.length === 20 && (gcContent(g) < 40 || gcContent(g) > 60) ? " (outside the usual 40 to 60% range)" : ""}. In the real RNA, T is written U.</p>
          <div className="max-h-40 overflow-auto rounded-lg border border-line divide-y divide-line">
            {candidates.length === 0 && <p className="p-3 text-sm text-slate-400">No NGG sites with a full 20-nt spacer in this sequence.</p>}
            {candidates.map((c, i) => (
              <button key={i} onClick={() => { setGrna(c.protospacer); setStep(0); }} className="w-full text-left px-3 py-1.5 text-xs hover:bg-white/5 flex justify-between gap-2" aria-label={`Use guide ${c.protospacer}`}>
                <span className="seq">{c.protospacer}<span className="text-amber">{c.pam}</span></span>
                <span className="text-slate-400 shrink-0">strand {c.strand}, GC {c.gc.toFixed(0)}%</span>
              </button>
            ))}
          </div>
        </div>

        <div className="card p-4">
          <h3 className="font-semibold mb-2">Guide check</h3>
          {!valid ? <p className="text-sm text-slate-400">Pick one of the listed guides or type a 20-nt spacer.</p> : (
            <div className="space-y-2 text-sm">
              {sites.length === 0 && <p className="text-amber">No site with up to 4 mismatches and an NGG PAM was found. Cas9 will not cut this sequence with this guide.</p>}
              {sites.map((s, i) => (
                <div key={i} className="rounded-lg border border-line p-2">
                  <div className="flex justify-between"><span className="font-mono">{s.strand} strand, pos {s.start + 1} to {s.start + 23}</span>
                    <span className={cleaves(s) ? "text-bio" : "text-slate-400"}>{s.mm === 0 ? "On-target" : cleaves(s) ? "Likely off-target cut" : "Unlikely to cut"}</span></div>
                  <div className="seq text-xs mt-1">{[...s.protospacer].map((c, k) => <span key={k} className={s.mismatches.includes(k) ? "text-red-400 underline" : "text-slate-300"}>{c}</span>)}<span className="text-amber">{s.pam}</span></div>
                  <div className="text-xs text-slate-500 mt-1">{s.mm} mismatches, {s.seedMM} in the seed (the 10 nt next to the PAM).</div>
                </div>
              ))}
              <p className="text-xs text-slate-500">Rule used: a PAM is required, and a site is called cleavable if the seed has no mismatch and there are at most 3 mismatches overall. Real specificity depends on mismatch type and position, so check with a dedicated off-target tool.</p>
            </div>
          )}
        </div>
      </div>

      <div className="card p-4">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          {steps.map((s, i) => (
            <button key={s} onClick={() => setStep(i)} disabled={!target && i > 0} className={`btn relative ${step === i ? "btn-primary" : ""}`}>{s}</button>
          ))}
        </div>

        {!target && valid && <p className="text-sm text-amber mb-3">This guide has no cleavable site in the sequence, so the later steps are locked.</p>}

        <div className="seq text-sm leading-7 bg-[#0a0f1c] border border-line rounded-lg p-3 overflow-x-auto" aria-label="Target sequence view">
          {step < 4 || !repair ? (
            [...seq].map((c, i) => {
              const cutHere = target && step >= 3 && i === target.cut;
              return <span key={i}>{cutHere && <span className="text-red-400 font-bold" title="Double-strand break">|</span>}<span className={colorFor(i)} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>{c}</span></span>;
            })
          ) : (
            <>
              <span>{repair.left}</span>
              {repair.mid && <span className="text-bio font-bold underline">{repair.mid}</span>}
              {repair.removed && <span className="text-red-400 line-through">{repair.removed}</span>}
              <span>{repair.right}</span>
            </>
          )}
        </div>
        {hover !== null && <p className="text-xs text-slate-500 mt-1">Position {hover + 1}</p>}

        <div className="mt-4 min-h-24">
          <AnimatePresence mode="wait">
            <motion.div key={step} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="text-sm space-y-2">
              {step === 0 && <p>Cas9 forms a complex with the gRNA. Pick a guide above, then step through the process. <span className="text-mol">Violet</span> will mark the protospacer, <span className="text-amber">amber</span> the PAM.</p>}
              {step === 1 && target && <p>The Cas9-gRNA complex scans the DNA. It first needs a PAM (<span className="text-amber seq">{target.pam}</span> here, matches NGG). Without a PAM, Cas9 does not unwind the DNA, even if the spacer matches.</p>}
              {step === 2 && target && <p>Next to the PAM the DNA is unwound and the gRNA pairs with the target strand, forming an R-loop. Pairing starts in the seed region (the 10 nt next to the PAM) and zips toward the far end. {target.mm === 0 ? "All 20 positions match." : `${target.mm} mismatch(es) here, none in the seed.`}</p>}
              {step === 3 && target && <p>The HNH domain cuts the target strand and the RuvC domain cuts the other strand, about 3 bp upstream of the PAM. The result is a blunt double-strand break (DSB) at the red bar, between positions {target.cut} and {target.cut + 1}.</p>}
              {step === 4 && target && repair && (
                <div className="space-y-3">
                  <div className="flex gap-2 flex-wrap">
                    <button className={`btn ${pathway === "nhej" ? "btn-primary" : ""}`} onClick={() => setPathway("nhej")}>NHEJ (no template)</button>
                    <button className={`btn ${pathway === "hdr" ? "btn-primary" : ""}`} onClick={() => setPathway("hdr")}>HDR (with donor template)</button>
                    {pathway === "nhej" && <button className="btn" onClick={() => setSeed((x) => x + 1)}><Scissors size={14} /> Another repair outcome</button>}
                  </div>
                  {pathway === "hdr" && <div><label className="label" htmlFor="donor">Donor insert (placed at the cut)</label><input id="donor" className="input seq" value={donor} onChange={(e) => setDonor(e.target.value.toUpperCase())} /></div>}
                  <p><b>{repair.kind}:</b> {repair.label}. Sequence length changes from {seq.length} to {repair.result.length} nt.{" "}
                    {repair.delta % 3 !== 0 ? <span className="text-red-400">The change is not a multiple of 3, so a coding sequence would be frameshifted (usually a knockout).</span> : <span className="text-bio">The change is a multiple of 3, so the reading frame is kept (an in-frame change).</span>}</p>
                  <p className="text-xs text-slate-500">{pathway === "nhej" ? "NHEJ is fast and error-prone: it often leaves small insertions or deletions at the cut, which is how knockouts are made. Each click shows one possible outcome, not a probability." : "HDR copies the donor template into the break. It needs a donor and mostly works in dividing cells (S/G2 phase), and it is much less frequent than NHEJ."}</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
        <div className="flex justify-between mt-2">
          <button className="btn" disabled={step === 0} onClick={() => setStep((s) => s - 1)}><ChevronLeft size={16} /> Back</button>
          <button className="btn btn-primary" disabled={!target || step >= 4} onClick={() => setStep((s) => s + 1)}>Next <ChevronRight size={16} /></button>
        </div>
      </div>
    </div>
  );
}
