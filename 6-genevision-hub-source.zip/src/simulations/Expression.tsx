import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { AA_INFO, CODON_TABLE, cleanDNA, complement, rnaOf, translateDNA } from "../lib/genetics";

// First 30 codons of the human HBB (beta-globin) coding sequence, plus an added stop codon, for teaching.
const WT = "ATGGTGCACCTGACTCCTGAGGAGAAGTCTGCCGTTACTGCCCTGTGGGGCAAGGTGAACGTGGATGAAGTTGGTGGTGAGGCCCTGGGCAGGTAA";
const aaColor = (a: string) => ("AVILMFWC".includes(a) ? "#F59E0B" : "STNQYG".includes(a) ? "#06B6D4" : "DE".includes(a) ? "#ef4444" : "KRH".includes(a) ? "#8B5CF6" : a === "P" ? "#10B981" : "#94a3b8");

export default function ExpressionSim() {
  const [mut, setMut] = useState(WT);
  const [pos, setPos] = useState(20);
  const [base, setBase] = useState("T");
  const [tStep, setTStep] = useState(30);
  const [aStep, setAStep] = useState(4);
  const [log, setLog] = useState<string[]>([]);

  const dna = cleanDNA(mut);
  const wtP = useMemo(() => translateDNA(WT), []);
  const mP = useMemo(() => translateDNA(dna), [dna]);
  const template = complement(dna); // template strand read 3' to 5' aligned under the coding strand
  const mrna = rnaOf(dna);
  const start = mP.start;

  const classify = () => {
    if (mut === WT) return { t: "Wild type", d: "No change from the reference sequence.", c: "text-slate-300" };
    if (mP.start < 0) return { t: "Start codon lost", d: "No AUG found, so translation cannot start.", c: "text-red-400" };
    const lenDiff = dna.length - WT.length;
    if (lenDiff % 3 !== 0) return { t: "Frameshift", d: `Net change of ${lenDiff > 0 ? "+" : ""}${lenDiff} nt. The reading frame shifts after the change, so downstream amino acids differ and a premature stop is likely.`, c: "text-red-400" };
    if (mP.protein === wtP.protein && mP.stopped === wtP.stopped) return { t: "Silent", d: "The DNA changed but the protein did not (the genetic code is degenerate).", c: "text-bio" };
    if (wtP.stopped && !mP.stopped) return { t: "Stop-loss (read-through)", d: "The stop codon is changed, so the ribosome keeps reading past the normal end and the protein becomes longer.", c: "text-red-400" };
    if (mP.protein.length < wtP.protein.length) return { t: "Nonsense (premature stop)", d: `The protein is truncated to ${mP.protein.length} amino acids instead of ${wtP.protein.length}.`, c: "text-red-400" };
    if (lenDiff !== 0) return { t: "In-frame insertion or deletion", d: `${Math.abs(lenDiff) / 3} amino acid(s) ${lenDiff > 0 ? "added" : "removed"}.`, c: "text-amber" };
    const i = [...mP.protein].findIndex((a, k) => a !== wtP.protein[k]);
    return { t: "Missense", d: `Amino acid ${i + 1}: ${AA_INFO[wtP.protein[i]]?.three ?? "Stop"} becomes ${AA_INFO[mP.protein[i]]?.three ?? "?"}.`, c: "text-amber" };
  };
  const cls = classify();

  const apply = (kind: "sub" | "ins" | "del") => {
    const i = Math.min(Math.max(pos, 1), dna.length) - 1;
    let n = dna;
    if (kind === "sub") n = dna.slice(0, i) + base + dna.slice(i + 1);
    if (kind === "ins") n = dna.slice(0, i) + base + dna.slice(i);
    if (kind === "del") n = dna.slice(0, i) + dna.slice(i + 1);
    setLog((l) => [`${kind === "sub" ? "Substitution" : kind === "ins" ? "Insertion" : "Deletion"} at position ${i + 1}${kind === "del" ? "" : " (" + base + ")"}`, ...l].slice(0, 6));
    setMut(n);
  };

  const codons: string[] = [];
  if (start >= 0) for (let p = start; p + 3 <= dna.length; p += 3) { codons.push(dna.slice(p, p + 3)); if (CODON_TABLE[dna.slice(p, p + 3)] === "*") break; }
  const aaCount = Math.min(aStep, codons.length);

  return (
    <div className="space-y-5">
      <div className="card p-4 space-y-3">
        <div className="flex flex-wrap justify-between gap-2">
          <h3 className="font-semibold">DNA coding strand (5' to 3')</h3>
          <button className="btn" onClick={() => { setMut(WT); setLog([]); }}>Reset to wild type</button>
        </div>
        <p className="text-xs text-slate-500">Reference: first 30 codons of human beta-globin (HBB) with an added stop codon. The sickle-cell mutation is GAG to GTG at codon 7 (Glu6Val in mature numbering): try substitution at position 20 with base T.</p>
        <div className="seq text-sm bg-[#0a0f1c] border border-line rounded-lg p-3 leading-7 overflow-x-auto">
          {[...dna].map((c, i) => <span key={i} className={i % 3 === 0 && i >= start ? "ml-1" : ""} style={{ color: WT[i] !== c ? "#F59E0B" : undefined }}>{c}</span>)}
        </div>
        <div className="flex flex-wrap gap-3 items-end">
          <div><label className="label" htmlFor="pos">Position (1 to {dna.length})</label><input id="pos" type="number" min={1} max={dna.length} value={pos} onChange={(e) => setPos(Number(e.target.value))} className="input w-28" /></div>
          <div><label className="label" htmlFor="base">Base</label><select id="base" className="input w-24" value={base} onChange={(e) => setBase(e.target.value)}>{["A", "C", "G", "T"].map((b) => <option key={b}>{b}</option>)}</select></div>
          <button className="btn" onClick={() => apply("sub")}>Substitute</button>
          <button className="btn" onClick={() => apply("ins")}>Insert before</button>
          <button className="btn btn-danger" onClick={() => apply("del")}>Delete base</button>
        </div>
        <div className="text-sm"><span className={`font-semibold ${cls.c}`}>{cls.t}.</span> <span className="text-slate-300">{cls.d}</span></div>
        {log.length > 0 && <p className="text-xs text-slate-500">Edits: {log.join(" , ")}</p>}
      </div>

      <div className="card p-4 space-y-3">
        <h3 className="font-semibold">Transcription: DNA to mRNA</h3>
        <p className="text-xs text-slate-500">RNA polymerase reads the template strand 3' to 5' and builds mRNA 5' to 3'. mRNA has the same sequence as the coding strand, with U in place of T.</p>
        <input type="range" min={0} max={dna.length} value={Math.min(tStep, dna.length)} onChange={(e) => setTStep(Number(e.target.value))} aria-label="Transcription progress" />
        <div className="seq text-sm overflow-x-auto whitespace-nowrap bg-[#0a0f1c] border border-line rounded-lg p-3 leading-7">
          <div><span className="text-slate-500 mr-2">coding  5'</span>{dna}</div>
          <div><span className="text-slate-500 mr-2">template 3'</span><span className="text-mol">{template}</span></div>
          <div><span className="text-slate-500 mr-2">mRNA    5'</span><span className="text-bio">{mrna.slice(0, tStep)}</span><motion.span className="text-amber" animate={{ opacity: [1, .3, 1] }} transition={{ repeat: Infinity, duration: 1.2 }}>{tStep < dna.length ? "▌" : ""}</motion.span></div>
        </div>
        <p className="text-xs text-slate-400">{tStep} of {dna.length} nucleotides transcribed.</p>
      </div>

      <div className="card p-4 space-y-3">
        <h3 className="font-semibold">Translation: mRNA to polypeptide</h3>
        {start < 0 ? <p className="text-sm text-red-400">No start codon (AUG). Nothing is translated.</p> : (<>
          <p className="text-xs text-slate-500">The ribosome starts at the first AUG, and each codon recruits a tRNA whose anticodon pairs with it. It stops at UAA, UAG or UGA.</p>
          <input type="range" min={0} max={codons.length} value={aaCount} onChange={(e) => setAStep(Number(e.target.value))} aria-label="Translation progress" />
          <div className="flex flex-wrap gap-2">
            {codons.map((cd, i) => {
              const aa = CODON_TABLE[cd]; const done = i < aaCount; const anti = rnaOf(complement(cd).split("").reverse().join(""));
              const w = translateDNA(WT).start + i * 3; const wtCodon = WT.slice(w, w + 3);
              const changed = wtCodon !== cd;
              return (
                <motion.div key={i} initial={false} animate={{ opacity: done ? 1 : 0.25, scale: done && i === aaCount - 1 ? 1.08 : 1 }} transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  className="rounded-xl border p-2 text-center w-[68px]" style={{ borderColor: changed ? "#F59E0B" : "#1E293B" }} title={`${AA_INFO[aa]?.name}. tRNA anticodon 5'-${anti}-3'`}>
                  <div className="seq text-xs text-slate-400">{rnaOf(cd)}</div>
                  <div className="text-lg font-bold" style={{ color: aaColor(aa) }}>{aa === "*" ? "Stop" : aa}</div>
                  <div className="text-[10px] text-slate-500">{AA_INFO[aa]?.three}</div>
                </motion.div>
              );
            })}
          </div>
          <div className="text-sm"><span className="text-slate-400">Protein: </span><span className="seq">{mP.protein.slice(0, aaCount)}</span></div>
          <div className="text-xs text-slate-500">Wild type: <span className="seq">{wtP.protein}</span> ({wtP.protein.length} aa). Current: {mP.protein.length} aa{mP.stopped ? ", ends at a stop codon" : ", no stop codon found (read-through)"}. Hover a codon to see its amino acid and tRNA anticodon. Amber outline = codon differs from wild type.</div>
        </>)}
      </div>
    </div>
  );
}
