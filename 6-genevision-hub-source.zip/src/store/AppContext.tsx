import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { backend } from "./backend";
import type { Project, Review, User } from "../lib/types";

interface Ctx {
  user: User | null;
  projects: Project[];
  reviews: Review[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  bookmarks: string[];
  toggleBookmark: (id: string) => void;
  mode: "cloud" | "local";
}
const C = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(C);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("gv_bookmarks") || "[]"); } catch { return []; }
  });

  const refresh = useCallback(async () => {
    try {
      const [u, p, r] = await Promise.all([backend.getUser(), backend.listProjects(), backend.listReviews()]);
      setUser(u); setProjects(p); setReviews(r); setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load data");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const toggleBookmark = (id: string) =>
    setBookmarks((b) => {
      const n = b.includes(id) ? b.filter((x) => x !== id) : [...b, id];
      localStorage.setItem("gv_bookmarks", JSON.stringify(n));
      return n;
    });

  const value = useMemo(() => ({ user, projects, reviews, loading, error, refresh, bookmarks, toggleBookmark, mode: backend.mode }), [user, projects, reviews, loading, error, refresh, bookmarks]);
  return <C.Provider value={value}>{children}</C.Provider>;
}
