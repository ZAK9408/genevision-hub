import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { Project, Review, Status, User } from "../lib/types";
import { SAMPLE_PROJECTS } from "../data/projects";

export interface Backend {
  mode: "cloud" | "local";
  getUser(): Promise<User | null>;
  signUp(email: string, password: string, name: string): Promise<{ needsConfirm: boolean }>;
  signIn(email: string, password: string): Promise<void>;
  signOut(): Promise<void>;
  listProjects(): Promise<Project[]>; // visible to current user (approved + own; all for admin)
  saveProject(p: Project): Promise<Project>;
  deleteProject(id: string): Promise<void>;
  setProjectStatus(id: string, s: Status): Promise<void>;
  listReviews(): Promise<Review[]>;
  saveReview(r: Omit<Review, "id" | "createdAt" | "status">): Promise<void>;
  deleteReview(id: string): Promise<void>;
  setReviewStatus(id: string, s: Status): Promise<void>;
  blockUser(userId: string, reason: string): Promise<void>;
  unblockUser(userId: string): Promise<void>;
  listBlocked(): Promise<{ userId: string; reason: string }[]>;
}

const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36));
const now = () => new Date().toISOString();

/* ---------------- Local demo backend (this browser only) ---------------- */
const LS = { projects: "gv_projects", reviews: "gv_reviews", user: "gv_user", blocked: "gv_blocked" };
const read = <T,>(k: string, d: T): T => { try { return JSON.parse(localStorage.getItem(k) || "") as T; } catch { return d; } };
const write = (k: string, v: unknown) => localStorage.setItem(k, JSON.stringify(v));

export const DEMO_ADMIN_EMAIL = "admin@demo.local";

const local: Backend = {
  mode: "local",
  async getUser() { return read<User | null>(LS.user, null); },
  async signUp(email, _pw, name) { write(LS.user, { id: "local-" + email, email, name, isAdmin: false } satisfies User); return { needsConfirm: false }; },
  async signIn(email) {
    const isAdmin = email.toLowerCase() === DEMO_ADMIN_EMAIL;
    write(LS.user, { id: "local-" + email, email, name: isAdmin ? "Demo Admin" : email.split("@")[0], isAdmin } satisfies User);
  },
  async signOut() { localStorage.removeItem(LS.user); },
  async listProjects() { return [...SAMPLE_PROJECTS, ...read<Project[]>(LS.projects, [])]; },
  async saveProject(p) {
    const list = read<Project[]>(LS.projects, []);
    const u = read<User | null>(LS.user, null);
    const saved: Project = { ...p, id: p.id || uid(), createdAt: p.createdAt || now(), ownerId: u?.id, status: "pending" };
    const i = list.findIndex((x) => x.id === saved.id);
    if (i >= 0) list[i] = saved; else list.push(saved);
    write(LS.projects, list);
    return saved;
  },
  async deleteProject(id) { write(LS.projects, read<Project[]>(LS.projects, []).filter((p) => p.id !== id)); },
  async setProjectStatus(id, s) { write(LS.projects, read<Project[]>(LS.projects, []).map((p) => (p.id === id ? { ...p, status: s } : p))); },
  async listReviews() { return read<Review[]>(LS.reviews, []); },
  async saveReview(r) {
    const u = read<User | null>(LS.user, null);
    write(LS.reviews, [...read<Review[]>(LS.reviews, []), { ...r, id: uid(), createdAt: now(), status: "pending", ownerId: u?.id }]);
  },
  async deleteReview(id) { write(LS.reviews, read<Review[]>(LS.reviews, []).filter((r) => r.id !== id)); },
  async setReviewStatus(id, s) { write(LS.reviews, read<Review[]>(LS.reviews, []).map((r) => (r.id === id ? { ...r, status: s } : r))); },
  async blockUser(userId, reason) { write(LS.blocked, [...read<{ userId: string; reason: string }[]>(LS.blocked, []), { userId, reason }]); },
  async unblockUser(userId) { write(LS.blocked, read<{ userId: string; reason: string }[]>(LS.blocked, []).filter((b) => b.userId !== userId)); },
  async listBlocked() { return read(LS.blocked, []); },
};

/* ---------------- Cloud backend (Supabase: Auth + Postgres + RLS) ---------------- */
type ProjectRow = {
  id: string; owner_id: string; title: string; author_name: string; author_role: string; track: string; abstract: string; methods: string;
  tools: string[]; findings: string[]; metrics: { label: string; value: string }[]; protocol_notes: string; simulation_ids: string[]; status: Status; created_at: string;
};
type ReviewRow = { id: string; owner_id: string; target_type: string; target_id: string; category: string; body: string; author_name: string; status: Status; created_at: string };

const toProject = (r: ProjectRow): Project => ({
  id: r.id, ownerId: r.owner_id, title: r.title, authorName: r.author_name, authorRole: r.author_role, track: r.track as Project["track"],
  abstract: r.abstract, methods: r.methods, tools: r.tools ?? [], findings: r.findings ?? [], metrics: r.metrics ?? [], protocolNotes: r.protocol_notes,
  simulationIds: (r.simulation_ids ?? []) as Project["simulationIds"], status: r.status, createdAt: r.created_at,
});
const toReview = (r: ReviewRow): Review => ({
  id: r.id, ownerId: r.owner_id, targetType: r.target_type as Review["targetType"], targetId: r.target_id, category: r.category as Review["category"],
  body: r.body, authorName: r.author_name, status: r.status, createdAt: r.created_at,
});

function makeCloud(sb: SupabaseClient): Backend {
  const must = <T,>(res: { data: T | null; error: { message: string } | null }): T => {
    if (res.error) throw new Error(res.error.message);
    return res.data as T;
  };
  return {
    mode: "cloud",
    async getUser() {
      const { data } = await sb.auth.getSession();
      const u = data.session?.user;
      if (!u) return null;
      const adm = await sb.rpc("is_admin");
      return { id: u.id, email: u.email ?? "", name: (u.user_metadata?.name as string) || (u.email ?? "").split("@")[0], isAdmin: adm.data === true };
    },
    async signUp(email, password, name) {
      const { data, error } = await sb.auth.signUp({ email, password, options: { data: { name } } });
      if (error) throw new Error(error.message);
      return { needsConfirm: !data.session };
    },
    async signIn(email, password) { const { error } = await sb.auth.signInWithPassword({ email, password }); if (error) throw new Error(error.message); },
    async signOut() { await sb.auth.signOut(); },
    async listProjects() {
      const rows = must(await sb.from("projects").select("*").order("created_at", { ascending: false })) as ProjectRow[];
      return [...SAMPLE_PROJECTS, ...rows.map(toProject)];
    },
    async saveProject(p) {
      const { data: s } = await sb.auth.getSession();
      const owner = s.session?.user.id;
      if (!owner) throw new Error("Please sign in first.");
      const row = {
        title: p.title, author_name: p.authorName, author_role: p.authorRole, track: p.track, abstract: p.abstract, methods: p.methods,
        tools: p.tools, findings: p.findings, metrics: p.metrics, protocol_notes: p.protocolNotes, simulation_ids: p.simulationIds, status: "pending" as Status,
      };
      if (p.id && !p.id.startsWith("draft-")) {
        const r = must(await sb.from("projects").update(row).eq("id", p.id).select().single()) as ProjectRow;
        return toProject(r);
      }
      const r = must(await sb.from("projects").insert({ ...row, owner_id: owner }).select().single()) as ProjectRow;
      return toProject(r);
    },
    async deleteProject(id) { must(await sb.from("projects").delete().eq("id", id).select()); },
    async setProjectStatus(id, s) { must(await sb.from("projects").update({ status: s }).eq("id", id).select()); },
    async listReviews() {
      return (must(await sb.from("reviews").select("*").order("created_at", { ascending: true })) as ReviewRow[]).map(toReview);
    },
    async saveReview(r) {
      const { data: s } = await sb.auth.getSession();
      const owner = s.session?.user.id;
      if (!owner) throw new Error("Please sign in first.");
      must(await sb.from("reviews").insert({ owner_id: owner, target_type: r.targetType, target_id: r.targetId, category: r.category, body: r.body, author_name: r.authorName, status: "pending" }).select());
    },
    async deleteReview(id) { must(await sb.from("reviews").delete().eq("id", id).select()); },
    async setReviewStatus(id, s) { must(await sb.from("reviews").update({ status: s }).eq("id", id).select()); },
    async blockUser(userId, reason) { must(await sb.from("blocked_users").upsert({ user_id: userId, reason }).select()); },
    async unblockUser(userId) { must(await sb.from("blocked_users").delete().eq("user_id", userId).select()); },
    async listBlocked() {
      return (must(await sb.from("blocked_users").select("*")) as { user_id: string; reason: string }[]).map((b) => ({ userId: b.user_id, reason: b.reason ?? "" }));
    },
  };
}

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const backend: Backend = url && key ? makeCloud(createClient(url, key)) : local;
