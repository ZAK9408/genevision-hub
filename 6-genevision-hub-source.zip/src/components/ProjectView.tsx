import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Copy, Check, Link2, Bookmark } from "lucide-react";
import type { Project } from "../lib/types";
import { SIMS } from "../lib/types";
import { useApp } from "../store/AppContext";

const TABS = ["Overview", "Results & Artifacts", "Methods & Protocol"] as const;

export default function ProjectView({ p, preview }: { p: Project; preview?: boolean }) {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Overview");
  const [copied, setCopied] = useState<string | null>(null);
  const { bookmarks, toggleBookmark } = useApp();
  const link = typeof window !== "undefined" ? window.location.href.split("#")[0] + `#/project/${p.id}` : "";
  const citation = `${p.authorName} (${new Date(p.createdAt).getFullYear()}). ${p.title}. GeneVision Hub. ${link}`;
  const copy = async (what: string, text: string) => {
    try { await navigator.clipboard.writeText(text); } catch { const t = document.createElement("textarea"); t.value = text; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove(); }
    setCopied(what); setTimeout(() => setCopied(null), 1500);
  };
  return (
    <article className="space-y-4">
      <div className="card p-5 space-y-3">
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-xs px-2 py-0.5 rounded-full bg-cyan/10 text-cyan">{p.track}</span>
          {p.sample && <span className="text-xs px-2 py-0.5 rounded-full bg-white/5 text-slate-400">Sample project (illustrative example)</span>}
          {p.status !== "approved" && <span className="text-xs px-2 py-0.5 rounded-full bg-amber/10 text-amber">Status: {p.status}</span>}
        </div>
        <h1 className="text-2xl font-bold">{p.title || "Untitled project"}</h1>
        <div className="text-sm text-slate-400">{p.authorName || "Author"}{p.authorRole ? `, ${p.authorRole}` : ""}</div>
        {!preview && (
          <div className="flex flex-wrap gap-2">
            <button className="btn" onClick={() => copy("link", link)}>{copied === "link" ? <Check size={15} /> : <Link2 size={15} />} Copy link</button>
            <button className="btn" onClick={() => copy("cite", citation)}>{copied === "cite" ? <Check size={15} /> : <Copy size={15} />} Copy citation</button>
            <button className="btn" onClick={() => toggleBookmark(p.id)}><Bookmark size={15} fill={bookmarks.includes(p.id) ? "currentColor" : "none"} /> {bookmarks.includes(p.id) ? "Saved" : "Save"}</button>
          </div>
        )}
      </div>

      <div className="flex gap-1 border-b border-line" role="tablist">
        {TABS.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`relative px-3 py-2 text-sm ${tab === t ? "text-cyan" : "text-slate-400"}`}>
            {t}{tab === t && <motion.span layoutId={`tab-${preview ? "p" : "d"}`} className="absolute left-0 right-0 -bottom-px h-0.5 bg-cyan" />}
          </button>
        ))}
      </div>

      {tab === "Overview" && (
        <div className="card p-5 space-y-4">
          <div><h3 className="label">Abstract</h3><p className="text-sm whitespace-pre-wrap">{p.abstract || "No abstract yet."}</p></div>
          {p.tools.length > 0 && <div><h3 className="label">Key tools and techniques</h3><div className="flex flex-wrap gap-2">{p.tools.map((t) => <span key={t} className="text-xs px-2 py-1 rounded-lg bg-white/5">{t}</span>)}</div></div>}
          {p.simulationIds.length > 0 && <div><h3 className="label">Linked simulations</h3><div className="flex flex-wrap gap-2">{p.simulationIds.map((id) => { const s = SIMS.find((x) => x.id === id)!; return <Link key={id} className="btn !text-xs" style={{ borderColor: s.color }} to={`/simulations/${id}`}>{s.title}</Link>; })}</div></div>}
        </div>
      )}
      {tab === "Results & Artifacts" && (
        <div className="card p-5 space-y-4">
          {p.metrics.length > 0 ? <div className="grid sm:grid-cols-3 gap-3">{p.metrics.map((m, i) => <div key={i} className="rounded-xl border border-line p-3"><div className="text-xs text-slate-400">{m.label}</div><div className="text-lg font-mono text-bio">{m.value}</div></div>)}</div> : <p className="text-sm text-slate-500">No metrics added.</p>}
          <div><h3 className="label">Key findings</h3>{p.findings.length ? <ul className="list-disc pl-5 text-sm space-y-1">{p.findings.map((f, i) => <li key={i}>{f}</li>)}</ul> : <p className="text-sm text-slate-500">No findings added.</p>}</div>
        </div>
      )}
      {tab === "Methods & Protocol" && (
        <div className="card p-5 space-y-4">
          <div><h3 className="label">Methodology summary</h3><p className="text-sm whitespace-pre-wrap">{p.methods || "Not provided."}</p></div>
          {p.protocolNotes && <div><h3 className="label">Protocol notes</h3><p className="text-sm whitespace-pre-wrap">{p.protocolNotes}</p></div>}
        </div>
      )}
    </article>
  );
}
