import { useState } from "react";
import { Link } from "react-router-dom";
import { CATEGORIES, type ReviewCategory } from "../lib/types";
import { useApp } from "../store/AppContext";
import { backend } from "../store/backend";

export default function Reviews({ targetType, targetId }: { targetType: "project" | "simulation"; targetId: string }) {
  const { reviews, user, refresh } = useApp();
  const [cat, setCat] = useState<ReviewCategory>("question");
  const [body, setBody] = useState("");
  const [filter, setFilter] = useState<ReviewCategory | "all">("all");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const mine = reviews.filter((r) => r.targetType === targetType && r.targetId === targetId);
  const visible = mine.filter((r) => r.status === "approved" && (filter === "all" || r.category === filter));
  const pending = mine.filter((r) => r.status !== "approved" && (r.ownerId === user?.id));

  const submit = async () => {
    if (body.trim().length < 3) return;
    setBusy(true); setMsg(null);
    try {
      await backend.saveReview({ targetType, targetId, category: cat, body: body.trim(), authorName: user?.name ?? "Anonymous" });
      setBody(""); setMsg("Thanks. Your contribution will appear after the site owner approves it.");
      await refresh();
    } catch (e) { setMsg(e instanceof Error ? e.message : "Could not post"); }
    setBusy(false);
  };

  return (
    <section className="card p-4 space-y-4" aria-label="Peer review and Q&A">
      <h3 className="font-semibold text-lg">Peer Review &amp; Q&amp;A</h3>
      <div className="flex flex-wrap gap-2">
        {(["all", ...CATEGORIES.map((c) => c.id)] as const).map((k) => (
          <button key={k} onClick={() => setFilter(k)} className={`btn !py-1 !text-xs ${filter === k ? "btn-primary" : ""}`}>{k === "all" ? "All" : CATEGORIES.find((c) => c.id === k)!.label}</button>
        ))}
      </div>
      {visible.length === 0 && <p className="text-sm text-slate-500">No approved contributions yet. Be the first to add one.</p>}
      <ul className="space-y-3">
        {visible.map((r) => { const c = CATEGORIES.find((x) => x.id === r.category)!; return (
          <li key={r.id} className="rounded-xl border border-line p-3">
            <div className="flex justify-between text-xs"><span className="font-semibold" style={{ color: c.color }}>{c.label}</span><span className="text-slate-500">{r.authorName}, {new Date(r.createdAt).toLocaleDateString()}</span></div>
            <p className="text-sm mt-1 whitespace-pre-wrap">{r.body}</p>
          </li>); })}
      </ul>
      {pending.length > 0 && <div className="text-xs text-amber">You have {pending.length} contribution(s) waiting for approval here.</div>}
      {user ? (
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">{CATEGORIES.map((c) => <button key={c.id} onClick={() => setCat(c.id)} className={`btn !py-1 !text-xs ${cat === c.id ? "btn-primary" : ""}`} title={c.hint}>{c.label}</button>)}</div>
          <p className="text-xs text-slate-500">{CATEGORIES.find((c) => c.id === cat)!.hint}</p>
          <textarea className="input h-24" value={body} onChange={(e) => setBody(e.target.value)} maxLength={2000} placeholder="Write a clear, constructive contribution" aria-label="Your contribution" />
          <div className="flex items-center gap-3"><button className="btn btn-primary" onClick={submit} disabled={busy || body.trim().length < 3}>Submit for review</button>{msg && <span className="text-xs text-slate-300">{msg}</span>}</div>
        </div>
      ) : <p className="text-sm text-slate-400"><Link to="/login" className="text-cyan underline">Sign in</Link> to ask a question or leave a review.</p>}
    </section>
  );
}
