import { Link } from "react-router-dom";
import { Bookmark } from "lucide-react";
import type { Project } from "../lib/types";
import { SIMS } from "../lib/types";
import { useApp } from "../store/AppContext";

export default function ProjectCard({ p }: { p: Project }) {
  const { bookmarks, toggleBookmark } = useApp();
  const saved = bookmarks.includes(p.id);
  return (
    <div className="card p-4 flex flex-col gap-2 hover:border-cyan/50 transition-colors">
      <div className="flex justify-between items-start gap-2">
        <span className="text-[11px] px-2 py-0.5 rounded-full bg-cyan/10 text-cyan">{p.track}</span>
        <button onClick={() => toggleBookmark(p.id)} aria-label={saved ? "Remove bookmark" : "Bookmark project"} className={saved ? "text-amber" : "text-slate-500 hover:text-slate-300"}><Bookmark size={18} fill={saved ? "currentColor" : "none"} /></button>
      </div>
      <Link to={`/project/${p.id}`} className="font-semibold leading-snug hover:text-cyan">{p.title}</Link>
      <p className="text-sm text-slate-400 line-clamp-3">{p.abstract}</p>
      <div className="mt-auto flex flex-wrap gap-1.5 pt-1">
        {p.simulationIds.map((id) => { const s = SIMS.find((x) => x.id === id)!; return <Link key={id} to={`/simulations/${id}`} className="text-[11px] px-2 py-0.5 rounded-full border" style={{ borderColor: s.color, color: s.color }}>{s.short}</Link>; })}
        {p.sample && <span className="text-[11px] px-2 py-0.5 rounded-full bg-white/5 text-slate-400">Sample</span>}
        {p.status !== "approved" && <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber/10 text-amber">{p.status}</span>}
      </div>
      <div className="text-xs text-slate-500">{p.authorName}, {p.authorRole}</div>
    </div>
  );
}
