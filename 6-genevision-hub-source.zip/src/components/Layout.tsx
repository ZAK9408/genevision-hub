import { NavLink, Outlet, Link } from "react-router-dom";
import { Dna, FlaskConical, LayoutGrid, PlusSquare, Bookmark, ShieldCheck, LogIn, LogOut } from "lucide-react";
import { useApp } from "../store/AppContext";
import { backend } from "../store/backend";

const links = [
  { to: "/simulations", label: "Simulations", icon: FlaskConical },
  { to: "/showcase", label: "Showcase", icon: LayoutGrid },
  { to: "/builder", label: "Project Builder", icon: PlusSquare },
  { to: "/saved", label: "Saved", icon: Bookmark },
];

export default function Layout() {
  const { user, refresh, mode, error } = useApp();
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-30 backdrop-blur bg-canvas/80 border-b border-line">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center gap-4">
          <Link to="/" className="flex items-center gap-2 font-bold"><Dna className="text-cyan" size={22} /> GeneVision <span className="text-cyan">Hub</span></Link>
          <nav className="hidden md:flex gap-1 ml-4" aria-label="Main">
            {links.map((l) => (
              <NavLink key={l.to} to={l.to} className={({ isActive }) => `px-3 py-1.5 rounded-lg text-sm flex items-center gap-1.5 ${isActive ? "bg-white/10 text-cyan" : "text-slate-300 hover:bg-white/5"}`}><l.icon size={15} />{l.label}</NavLink>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            {user?.isAdmin && <NavLink to="/admin" className="btn !py-1.5"><ShieldCheck size={15} className="text-amber" /> Admin</NavLink>}
            {user ? (
              <button className="btn !py-1.5" onClick={async () => { await backend.signOut(); await refresh(); }}><LogOut size={15} /><span className="hidden sm:inline">{user.name}</span></button>
            ) : (
              <NavLink to="/login" className="btn btn-primary !py-1.5"><LogIn size={15} /> Sign in</NavLink>
            )}
          </div>
        </div>
        <nav className="md:hidden flex overflow-x-auto gap-1 px-3 pb-2" aria-label="Main mobile">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} className={({ isActive }) => `px-3 py-1 rounded-lg text-xs whitespace-nowrap ${isActive ? "bg-white/10 text-cyan" : "text-slate-300"}`}>{l.label}</NavLink>
          ))}
        </nav>
      </header>
      {mode === "local" && (
        <div className="bg-amber/10 border-b border-amber/30 text-amber text-xs text-center py-1.5 px-3">Demo mode: no shared database is connected, so projects and reviews are saved only in this browser.</div>
      )}
      {error && <div className="bg-red-500/10 border-b border-red-500/30 text-red-300 text-xs text-center py-1.5 px-3">Could not reach the database: {error}</div>}
      <main className="flex-1"><Outlet /></main>
      <footer className="border-t border-line text-xs text-slate-500 py-6 text-center px-4">
        GeneVision Hub. Simulations are simplified educational models, not substitutes for lab validation. Sample projects are illustrative examples.
      </footer>
    </div>
  );
}
