import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Check, X, Trash2, Ban } from "lucide-react";
import { useApp } from "../store/AppContext";
import { backend } from "../store/backend";
import type { Status } from "../lib/types";
import { CATEGORIES } from "../lib/types";

export default function Admin() {
  const { user, projects, reviews, refresh, loading } = useApp();
  const [tab, setTab] = useState<"projects" | "reviews" | "blocked">("projects");
  const [filter, setFilter] = useState<Status | "all">("pending");
  const [blocked, setBlocked] = useState<{ userId: string; reason: string }[]>([]);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { backend.listBlocked().then(setBlocked).catch(() => undefined); }, [tab]);
  if (loading) return <div className="p-8 text-slate-400">Loading...</div>;
  if (!user?.isAdmin) return <div className="max-w-xl mx-auto px-4 py-10"><p>This page is for the site owner. <Link to="/login" className="text-cyan underline">Sign in</Link> with the admin account.</p></div>;

  const run = async (fn: () => Promise<void>) => { setErr(null); try { await fn(); await refresh(); setBlocked(await backend.listBlocked()); } catch (e) { setErr(e instanceof Error ? e.message : "Failed"); } };
  const ps = projects.filter((p) => !p.sample && (filter === "all" || p.status === filter));
  const rs = reviews.filter((r) => filter === "all" || r.status === filter);
  const pend = (list: { status: Status }[]) => list.filter((x) => x.status === "pending").length;
  const block = (ownerId?: string) => { if (!ownerId) return; const reason = prompt("Reason for blocking this user (optional)") ?? ""; void run(() => backend.blockUser(ownerId, reason)); };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-5">
      <h1 className="text-3xl font-bold">Admin panel</h1>
      <div className="flex flex-wrap gap-2">
        <button className={`btn ${tab === "projects" ? "btn-primary" : ""}`} onClick={() => setTab("projects")}>Projects ({pend(projects.filter((p) => !p.sample))} pending)</button>
        <button className={`btn ${tab === "reviews" ? "btn-primary" : ""}`} onClick={() => setTab("reviews")}>Reviews &amp; comments ({pend(reviews)} pending)</button>
        <button className={`btn ${tab === "blocked" ? "btn-primary" : ""}`} onClick={() => setTab("blocked")}>Blocked users ({blocked.length})</button>
      </div>
      {tab !== "blocked" && <div className="flex gap-2 text-xs">{(["pending", "approved", "rejected", "all"] as const).map((f) => <button key={f} className={`btn !py-1 !text-xs ${filter === f ? "btn-primary" : ""}`} onClick={() => setFilter(f)}>{f}</button>)}</div>}
      {err && <p className="text-sm text-red-300">{err}</p>}

      {tab === "projects" && (ps.length === 0 ? <p className="text-slate-500 text-sm">Nothing here.</p> : ps.map((p) => (
        <div key={p.id} className="card p-4 space-y-2">
          <div className="flex justify-between gap-2"><Link to={`/project/${p.id}`} className="font-semibold hover:text-cyan">{p.title}</Link><span className="text-xs text-amber">{p.status}</span></div>
          <div className="text-xs text-slate-500">{p.authorName}, {p.authorRole}, {new Date(p.createdAt).toLocaleString()}</div>
          <p className="text-sm text-slate-300 line-clamp-3">{p.abstract}</p>
          <div className="flex flex-wrap gap-2">
            <button className="btn !py-1 !text-xs" onClick={() => run(() => backend.setProjectStatus(p.id, "approved"))}><Check size={14} className="text-bio" /> Approve</button>
            <button className="btn !py-1 !text-xs" onClick={() => run(() => backend.setProjectStatus(p.id, "rejected"))}><X size={14} /> Reject</button>
            <button className="btn btn-danger !py-1 !text-xs" onClick={() => confirm("Delete this project permanently?") && run(() => backend.deleteProject(p.id))}><Trash2 size={14} /> Delete</button>
            <button className="btn btn-danger !py-1 !text-xs" onClick={() => block(p.ownerId)}><Ban size={14} /> Block author</button>
          </div>
        </div>)))}

      {tab === "reviews" && (rs.length === 0 ? <p className="text-slate-500 text-sm">Nothing here.</p> : rs.map((r) => {
        const proj = projects.find((p) => p.id === r.targetId);
        return (
          <div key={r.id} className="card p-4 space-y-2">
            <div className="flex justify-between text-xs"><span style={{ color: CATEGORIES.find((c) => c.id === r.category)?.color }}>{CATEGORIES.find((c) => c.id === r.category)?.label} on {r.targetType}: {proj?.title ?? r.targetId}</span><span className="text-amber">{r.status}</span></div>
            <p className="text-sm whitespace-pre-wrap">{r.body}</p>
            <div className="text-xs text-slate-500">{r.authorName}, {new Date(r.createdAt).toLocaleString()}</div>
            <div className="flex flex-wrap gap-2">
              <button className="btn !py-1 !text-xs" onClick={() => run(() => backend.setReviewStatus(r.id, "approved"))}><Check size={14} className="text-bio" /> Approve</button>
              <button className="btn !py-1 !text-xs" onClick={() => run(() => backend.setReviewStatus(r.id, "rejected"))}><X size={14} /> Reject</button>
              <button className="btn btn-danger !py-1 !text-xs" onClick={() => run(() => backend.deleteReview(r.id))}><Trash2 size={14} /> Delete</button>
              <button className="btn btn-danger !py-1 !text-xs" onClick={() => block(r.ownerId)}><Ban size={14} /> Block author</button>
            </div>
          </div>);
      }))}

      {tab === "blocked" && (blocked.length === 0 ? <p className="text-slate-500 text-sm">No blocked users.</p> : blocked.map((b) => (
        <div key={b.userId} className="card p-4 flex justify-between items-center gap-2"><div><div className="font-mono text-xs">{b.userId}</div><div className="text-sm text-slate-400">{b.reason || "No reason given"}</div></div>
          <button className="btn !py-1 !text-xs" onClick={() => run(() => backend.unblockUser(b.userId))}>Unblock</button></div>)))}
    </div>
  );
}
