import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Plus, Trash2, Save, Send } from "lucide-react";
import { SIMS, TRACKS, type Project, type SimId, type Track } from "../lib/types";
import { useApp } from "../store/AppContext";
import { backend } from "../store/backend";
import ProjectView from "../components/ProjectView";

const blank = (): Project => ({ id: "", title: "", authorName: "", authorRole: "", track: "Molecular Biology", abstract: "", methods: "", tools: [], findings: [], metrics: [], protocolNotes: "", simulationIds: [], status: "pending", createdAt: new Date().toISOString() });
const STEPS = ["Basics", "Methods", "Results", "Simulations", "Preview & submit"] as const;

function ListEditor({ label, items, onChange, placeholder }: { label: string; items: string[]; onChange: (v: string[]) => void; placeholder: string }) {
  return (
    <div><span className="label">{label}</span>
      {items.map((t, i) => <div key={i} className="flex gap-2 mb-2"><input className="input" value={t} onChange={(e) => onChange(items.map((x, k) => (k === i ? e.target.value : x)))} aria-label={`${label} ${i + 1}`} /><button className="btn" onClick={() => onChange(items.filter((_, k) => k !== i))} aria-label="Remove"><Trash2 size={15} /></button></div>)}
      <button className="btn !text-xs" onClick={() => onChange([...items, ""])}><Plus size={14} /> {placeholder}</button></div>
  );
}

export default function Builder() {
  const { id } = useParams();
  const { projects, user, refresh, loading } = useApp();
  const nav = useNavigate();
  const key = "gv_draft_" + (id ?? "new");
  const [p, setP] = useState<Project>(() => { try { return JSON.parse(localStorage.getItem(key) || "") as Project; } catch { return blank(); } });
  const [step, setStep] = useState(0);
  const [toolTxt, setToolTxt] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(!id);

  useEffect(() => {
    if (id && !loaded && !loading) {
      const ex = projects.find((x) => x.id === id && x.ownerId === user?.id);
      if (ex && !localStorage.getItem(key)) setP(ex);
      setLoaded(true);
    }
  }, [id, loaded, loading, projects, user, key]);

  useEffect(() => { if (loaded) localStorage.setItem(key, JSON.stringify(p)); }, [p, key, loaded]);
  useEffect(() => { if (user && !p.authorName) setP((x) => ({ ...x, authorName: user.name })); }, [user]); // eslint-disable-line

  const set = <K extends keyof Project>(k: K, v: Project[K]) => setP((x) => ({ ...x, [k]: v }));
  const valid = p.title.trim().length >= 3 && p.authorName.trim() && p.abstract.trim().length >= 30;

  const submit = async () => {
    setBusy(true); setMsg(null);
    try {
      const saved = await backend.saveProject({ ...p, id: id ?? p.id });
      localStorage.removeItem(key);
      await refresh();
      setMsg("Submitted. The site owner will review it before it is shown publicly.");
      setTimeout(() => nav("/saved"), 1200);
      void saved;
    } catch (e) { setMsg(e instanceof Error ? e.message : "Could not submit"); }
    setBusy(false);
  };

  if (!user) return <div className="max-w-3xl mx-auto px-4 py-10"><p>You can write your project here, but you need to <Link to="/login" className="text-cyan underline">sign in</Link> to submit it. Your draft is saved in this browser.</p></div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-5">
      <h1 className="text-3xl font-bold">{id ? "Edit project" : "Project Builder"}</h1>
      <div className="flex gap-2 flex-wrap">{STEPS.map((s, i) => <button key={s} onClick={() => setStep(i)} className={`btn !py-1 !text-xs ${step === i ? "btn-primary" : ""}`}>{i + 1}. {s}</button>)}</div>
      <div className="card p-5 space-y-4">
        {step === 0 && (<>
          <div><label className="label" htmlFor="t">Title</label><input id="t" className="input" maxLength={200} value={p.title} onChange={(e) => set("title", e.target.value)} /></div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div><label className="label" htmlFor="a">Author name</label><input id="a" className="input" maxLength={120} value={p.authorName} onChange={(e) => set("authorName", e.target.value)} /></div>
            <div><label className="label" htmlFor="r">Role (e.g. Undergraduate, MSc student)</label><input id="r" className="input" maxLength={160} value={p.authorRole} onChange={(e) => set("authorRole", e.target.value)} /></div>
          </div>
          <div><label className="label" htmlFor="tr">Track / domain</label><select id="tr" className="input" value={p.track} onChange={(e) => set("track", e.target.value as Track)}>{TRACKS.map((t) => <option key={t}>{t}</option>)}</select></div>
          <div><label className="label" htmlFor="ab">Abstract (at least 30 characters)</label><textarea id="ab" className="input h-36" maxLength={5000} value={p.abstract} onChange={(e) => set("abstract", e.target.value)} /></div>
        </>)}
        {step === 1 && (<>
          <div><label className="label" htmlFor="m">Methods summary</label><textarea id="m" className="input h-36" maxLength={8000} value={p.methods} onChange={(e) => set("methods", e.target.value)} /></div>
          <div><span className="label">Key tools and techniques</span>
            <div className="flex flex-wrap gap-2 mb-2">{p.tools.map((t) => <button key={t} className="text-xs px-2 py-1 rounded-lg bg-white/5" onClick={() => set("tools", p.tools.filter((x) => x !== t))}>{t} x</button>)}</div>
            <div className="flex gap-2"><input className="input" value={toolTxt} onChange={(e) => setToolTxt(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && toolTxt.trim()) { set("tools", [...p.tools, toolTxt.trim()]); setToolTxt(""); } }} placeholder="Type a tool and press Enter" aria-label="Add tool" /><button className="btn" onClick={() => { if (toolTxt.trim()) { set("tools", [...p.tools, toolTxt.trim()]); setToolTxt(""); } }}>Add</button></div></div>
          <div><label className="label" htmlFor="pn">Protocol notes</label><textarea id="pn" className="input h-24" maxLength={5000} value={p.protocolNotes} onChange={(e) => set("protocolNotes", e.target.value)} /></div>
        </>)}
        {step === 2 && (<>
          <ListEditor label="Key findings" items={p.findings} onChange={(v) => set("findings", v)} placeholder="Add a finding" />
          <div><span className="label">Result highlights (metrics)</span>
            {p.metrics.map((m, i) => <div key={i} className="flex gap-2 mb-2"><input className="input" placeholder="Label" value={m.label} onChange={(e) => set("metrics", p.metrics.map((x, k) => (k === i ? { ...x, label: e.target.value } : x)))} aria-label={`Metric label ${i + 1}`} /><input className="input" placeholder="Value" value={m.value} onChange={(e) => set("metrics", p.metrics.map((x, k) => (k === i ? { ...x, value: e.target.value } : x)))} aria-label={`Metric value ${i + 1}`} /><button className="btn" onClick={() => set("metrics", p.metrics.filter((_, k) => k !== i))} aria-label="Remove"><Trash2 size={15} /></button></div>)}
            <button className="btn !text-xs" onClick={() => set("metrics", [...p.metrics, { label: "", value: "" }])}><Plus size={14} /> Add metric</button></div>
        </>)}
        {step === 3 && (<div className="space-y-2"><p className="text-sm text-slate-400">Link the simulations related to your work. They show on your project page.</p>
          {SIMS.map((s) => { const on = p.simulationIds.includes(s.id); return <label key={s.id} className="flex items-center gap-3 rounded-xl border border-line p-3 cursor-pointer"><input type="checkbox" checked={on} onChange={() => set("simulationIds", on ? p.simulationIds.filter((x) => x !== s.id) : [...p.simulationIds, s.id as SimId])} /><span>{s.title}</span></label>; })}</div>)}
        {step === 4 && (<div className="space-y-4">
          <p className="text-sm text-slate-400">This is how your project page will look. It becomes public only after the site owner approves it.</p>
          <ProjectView p={{ ...p, authorName: p.authorName || user.name }} preview />
          {!valid && <p className="text-sm text-amber">Needed before submitting: a title, an author name and an abstract of at least 30 characters.</p>}
          <button className="btn btn-primary" disabled={!valid || busy} onClick={submit}><Send size={16} /> Submit for approval</button>
        </div>)}
        {msg && <p className="text-sm text-slate-200">{msg}</p>}
      </div>
      <div className="flex justify-between">
        <button className="btn" disabled={step === 0} onClick={() => setStep(step - 1)}>Back</button>
        <span className="text-xs text-slate-500 flex items-center gap-1"><Save size={13} /> Draft saved in this browser</span>
        <button className="btn" disabled={step === STEPS.length - 1} onClick={() => setStep(step + 1)}>Next</button>
      </div>
    </div>
  );
}
