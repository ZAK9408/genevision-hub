import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { SIMS, TRACKS, type SimId, type Track } from "../lib/types";
import { useApp } from "../store/AppContext";
import ProjectCard from "../components/ProjectCard";
import ProjectView from "../components/ProjectView";
import Reviews from "../components/Reviews";

export function Showcase() {
  const { projects, loading } = useApp();
  const [track, setTrack] = useState<Track | "all">("all");
  const [sim, setSim] = useState<SimId | "all">("all");
  const [q, setQ] = useState("");
  const list = projects.filter((p) => p.status === "approved" && (track === "all" || p.track === track) && (sim === "all" || p.simulationIds.includes(sim)) && (q === "" || (p.title + p.abstract + p.tools.join(" ")).toLowerCase().includes(q.toLowerCase())));
  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-5">
      <div className="flex flex-wrap justify-between gap-3 items-end">
        <div><h1 className="text-3xl font-bold">Project &amp; Research Showcase</h1><p className="text-slate-400 text-sm">Approved student and researcher projects.</p></div>
        <Link to="/builder" className="btn btn-primary">Submit your project</Link>
      </div>
      <div className="relative"><Search size={16} className="absolute left-3 top-3 text-slate-500" /><input className="input !pl-9" placeholder="Search title, abstract or tools" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search projects" /></div>
      <div className="flex flex-wrap gap-2">
        {(["all", ...TRACKS] as const).map((t) => (
          <button key={t} onClick={() => setTrack(t)} className={`relative btn !py-1 !text-xs ${track === t ? "!text-cyan" : ""}`}>{t === "all" ? "All subfields" : t}{track === t && <motion.span layoutId="track-ind" className="absolute inset-0 rounded-[10px] border border-cyan" />}</button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2 items-center"><span className="text-xs text-slate-500">Technique:</span>
        {(["all", ...SIMS.map((s) => s.id)] as const).map((s) => (
          <button key={s} onClick={() => setSim(s)} className={`relative btn !py-1 !text-xs ${sim === s ? "!text-cyan" : ""}`}>{s === "all" ? "Any" : SIMS.find((x) => x.id === s)!.short}{sim === s && <motion.span layoutId="sim-ind" className="absolute inset-0 rounded-[10px] border border-cyan" />}</button>
        ))}
      </div>
      {loading ? <p className="text-slate-400">Loading...</p> : list.length === 0 ? <p className="text-slate-500">No projects match these filters.</p> :
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{list.map((p) => <ProjectCard key={p.id} p={p} />)}</div>}
    </div>
  );
}

export function ProjectDetail() {
  const { id } = useParams();
  const { projects, user, loading } = useApp();
  const p = projects.find((x) => x.id === id);
  if (loading) return <div className="max-w-4xl mx-auto px-4 py-8 text-slate-400">Loading...</div>;
  const canSee = p && (p.status === "approved" || p.ownerId === user?.id || user?.isAdmin);
  if (!p || !canSee) return <div className="max-w-4xl mx-auto px-4 py-8"><p className="text-slate-300">This project was not found, or it is not approved yet.</p><Link to="/showcase" className="text-cyan">Back to the showcase</Link></div>;
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <Link to="/showcase" className="text-sm text-slate-400 hover:text-cyan">Back to showcase</Link>
      <ProjectView p={p} />
      {p.ownerId && p.ownerId === user?.id && <Link to={`/builder/${p.id}`} className="btn">Edit this project (resubmits for approval)</Link>}
      {p.status === "approved" && <Reviews targetType="project" targetId={p.id} />}
    </div>
  );
}

export function Saved() {
  const { projects, bookmarks, user } = useApp();
  const saved = projects.filter((p) => bookmarks.includes(p.id) && (p.status === "approved" || p.ownerId === user?.id));
  const mine = projects.filter((p) => user && p.ownerId === user.id);
  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      <section><h1 className="text-2xl font-bold mb-3">Saved projects</h1>
        {saved.length ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{saved.map((p) => <ProjectCard key={p.id} p={p} />)}</div> : <p className="text-slate-500 text-sm">Nothing saved yet. Use the bookmark icon on any project.</p>}</section>
      <section><h2 className="text-2xl font-bold mb-3">My projects</h2>
        {!user ? <p className="text-sm text-slate-500"><Link to="/login" className="text-cyan">Sign in</Link> to see your submissions and their approval status.</p> :
          mine.length ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{mine.map((p) => <div key={p.id} className="space-y-2"><ProjectCard p={p} /><Link className="btn !text-xs" to={`/builder/${p.id}`}>Edit</Link></div>)}</div> : <p className="text-sm text-slate-500">You have not submitted a project yet.</p>}</section>
    </div>
  );
}
