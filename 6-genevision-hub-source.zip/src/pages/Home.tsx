import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Dna, FlaskConical, Users, MessagesSquare } from "lucide-react";
import { SIMS } from "../lib/types";
import { useApp } from "../store/AppContext";
import ProjectCard from "../components/ProjectCard";

export default function Home() {
  const { projects } = useApp();
  const featured = projects.filter((p) => p.status === "approved").slice(0, 3);
  const fade = { hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0 } };
  return (
    <div>
      <section className="relative overflow-hidden border-b border-line">
        <div className="absolute inset-0 opacity-30" style={{ background: "radial-gradient(600px 300px at 20% 10%, #06B6D455, transparent), radial-gradient(500px 300px at 85% 30%, #8B5CF655, transparent)" }} />
        <div className="relative max-w-6xl mx-auto px-4 py-16 md:py-24">
          <motion.div variants={fade} initial="hidden" animate="show" transition={{ type: "spring", stiffness: 80, damping: 18 }}>
            <span className="inline-flex items-center gap-2 text-xs px-3 py-1 rounded-full border border-line bg-surface text-cyan"><Dna size={14} /> Molecular biology, visualized and shared</span>
            <h1 className="mt-4 text-4xl md:text-6xl font-extrabold tracking-tight max-w-3xl">See how molecular biology works, then show what you built with it.</h1>
            <p className="mt-4 text-slate-300 max-w-2xl">Run hands-on simulations of PCR, CRISPR-Cas9 and gene expression, then publish your own student or research project, linked to the technique it uses, and get structured peer review.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/simulations" className="btn btn-primary">Open the Simulation Lab <ArrowRight size={16} /></Link>
              <Link to="/showcase" className="btn">Browse projects</Link>
              <Link to="/builder" className="btn">Build a project</Link>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold mb-1 flex items-center gap-2"><FlaskConical className="text-cyan" /> Interactive Simulation Lab</h2>
        <p className="text-slate-400 text-sm mb-5">Change parameters and watch the molecular process respond.</p>
        <div className="grid md:grid-cols-3 gap-4">
          {SIMS.map((s, i) => (
            <motion.div key={s.id} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}>
              <Link to={`/simulations/${s.id}`} className="card p-5 block hover:border-cyan/60 transition-colors h-full">
                <div className="w-10 h-10 rounded-xl mb-3 flex items-center justify-center" style={{ background: s.color + "22", color: s.color }}><Dna size={20} /></div>
                <div className="font-semibold">{s.title}</div>
                <p className="text-sm text-slate-400 mt-1">{s.id === "pcr" ? "Tune temperatures, times and cycles. See yield, specificity and a gel preview." : s.id === "crispr" ? "Pick a gRNA, check the PAM, watch cleavage, then compare NHEJ and HDR repair." : "Step DNA to mRNA to protein and see what silent, missense, nonsense and frameshift mutations do."}</p>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 pb-12">
        <div className="flex justify-between items-end mb-5"><h2 className="text-2xl font-bold flex items-center gap-2"><Users className="text-bio" /> Project &amp; Research Showcase</h2><Link to="/showcase" className="text-sm text-cyan">See all</Link></div>
        <div className="grid md:grid-cols-3 gap-4">{featured.map((p) => <ProjectCard key={p.id} p={p} />)}</div>
      </section>

      <section className="max-w-6xl mx-auto px-4 pb-16">
        <div className="card p-6 grid md:grid-cols-3 gap-6">
          {[["Build", "Write your project step by step and link it to a simulation.", Users], ["Get reviewed", "Every project and comment is approved by the site owner before it appears.", MessagesSquare], ["Share", "Copy a link or citation for your CV and portfolio.", ArrowRight]].map(([t, d, Icon]) => {
            const I = Icon as typeof Users; return <div key={t as string}><I className="text-cyan mb-2" size={20} /><div className="font-semibold">{t as string}</div><p className="text-sm text-slate-400">{d as string}</p></div>; })}
        </div>
      </section>
    </div>
  );
}
