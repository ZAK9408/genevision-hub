import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { backend, DEMO_ADMIN_EMAIL } from "../store/backend";
import { useApp } from "../store/AppContext";

export default function Login() {
  const { refresh, mode } = useApp();
  const nav = useNavigate();
  const [signup, setSignup] = useState(false);
  const [email, setEmail] = useState(""); const [pw, setPw] = useState(""); const [name, setName] = useState("");
  const [msg, setMsg] = useState<string | null>(null); const [busy, setBusy] = useState(false);
  const go = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    try {
      if (signup) {
        const r = await backend.signUp(email.trim(), pw, name.trim() || email.split("@")[0]);
        if (r.needsConfirm) { setMsg("Account created. Check your email to confirm, then sign in."); setBusy(false); return; }
      } else await backend.signIn(email.trim(), pw);
      await refresh(); nav("/");
    } catch (er) { setMsg(er instanceof Error ? er.message : "Failed"); }
    setBusy(false);
  };
  return (
    <div className="max-w-sm mx-auto px-4 py-12">
      <form onSubmit={go} className="card p-6 space-y-4">
        <h1 className="text-2xl font-bold">{signup ? "Create account" : "Sign in"}</h1>
        {signup && <div><label className="label" htmlFor="n">Display name</label><input id="n" className="input" value={name} onChange={(e) => setName(e.target.value)} /></div>}
        <div><label className="label" htmlFor="e">Email</label><input id="e" type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label className="label" htmlFor="p">Password</label><input id="p" type="password" required minLength={mode === "cloud" ? 8 : 1} className="input" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
        <button className="btn btn-primary w-full justify-center" disabled={busy}>{signup ? "Sign up" : "Sign in"}</button>
        {msg && <p className="text-sm text-amber">{msg}</p>}
        <button type="button" className="text-sm text-cyan" onClick={() => setSignup(!signup)}>{signup ? "I already have an account" : "Create a new account"}</button>
        {mode === "local" && <p className="text-xs text-slate-500">Demo mode: any password works. To try the admin panel, sign in with <span className="font-mono">{DEMO_ADMIN_EMAIL}</span>. Admin actions affect only this browser.</p>}
      </form>
    </div>
  );
}
