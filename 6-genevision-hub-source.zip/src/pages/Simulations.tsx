import { Link, useParams, Navigate } from "react-router-dom";
import { SIMS } from "../lib/types";
import { useApp } from "../store/AppContext";
import PCRSim from "../simulations/PCR";
import CrisprSim from "../simulations/Crispr";
import ExpressionSim from "../simulations/Expression";
import ProjectCard from "../components/ProjectCard";
import Reviews from "../components/Reviews";
import { motion } from "framer-motion";

export function SimulationsIndex() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-2">Interactive Simulation Lab</h1>
      <p className="text-slate-400 mb-6">Pick a process. Every control changes the result straight away.</p>
      <div className="grid md:grid-cols-3 gap-4">
        {SIMS.map((s) => (
          <Link key={s.id} to={`/simulations/${s.id}`} className="card p-5 hover:border-cyan/60 transition-colors">
            <div className="h-1.5 w-12 rounded mb-3" style={{ background: s.color }} />
            <div className="font-semibold">{s.title}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export function SimulationPage() {
  const { id } = useParams();
  const { projects } = useApp();
  const sim = SIMS.find((s) => s.id === id);
  if (!sim) return <Navigate to="/simulations" replace />;
  const related = projects.filter((p) => p.status === "approved" && p.simulationIds.includes(sim.id));
  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      <div>
        <div className="flex gap-2 mb-3 flex-wrap">{SIMS.map((s) => (
          <Link key={s.id} to={`/simulations/${s.id}`} className={`relative btn !py-1 !text-xs ${s.id === sim.id ? "!text-cyan" : ""}`}>
            {s.short}{s.id === sim.id && <motion.span layoutId="sim-tab" className="absolute inset-0 rounded-[10px] border border-cyan" />}
          </Link>))}</div>
        <h1 className="text-3xl font-bold">{sim.title}</h1>
      </div>
      {sim.id === "pcr" && <PCRSim />}
      {sim.id === "crispr" && <CrisprSim />}
      {sim.id === "expression" && <ExpressionSim />}
      <section>
        <h2 className="text-xl font-bold mb-3">Projects that use this technique</h2>
        {related.length ? <div className="grid md:grid-cols-3 gap-4">{related.map((p) => <ProjectCard key={p.id} p={p} />)}</div> : <p className="text-sm text-slate-500">No approved projects yet. <Link to="/builder" className="text-cyan">Build one</Link> and link this simulation.</p>}
      </section>
      <Reviews targetType="simulation" targetId={sim.id} />
    </div>
  );
}
