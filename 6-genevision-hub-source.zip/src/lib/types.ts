export type Track = "Molecular Biology" | "Genetics" | "Microbiology" | "Cell/Tissue Culture" | "Biotechnology/Bioprocess" | "Bioinformatics";
export const TRACKS: Track[] = ["Molecular Biology", "Genetics", "Microbiology", "Cell/Tissue Culture", "Biotechnology/Bioprocess", "Bioinformatics"];

export type SimId = "pcr" | "crispr" | "expression";
export const SIMS: { id: SimId; title: string; short: string; color: string }[] = [
  { id: "pcr", title: "PCR Thermal Cycling Simulator", short: "PCR", color: "#06B6D4" },
  { id: "crispr", title: "CRISPR-Cas9 Gene Editing Simulator", short: "CRISPR-Cas9", color: "#8B5CF6" },
  { id: "expression", title: "Gene Expression: Transcription & Translation", short: "Transcription & Translation", color: "#10B981" },
];

export type Status = "pending" | "approved" | "rejected";

export interface Metric { label: string; value: string }
export interface Project {
  id: string;
  title: string;
  authorName: string;
  authorRole: string;
  track: Track;
  abstract: string;
  methods: string;
  tools: string[];
  findings: string[];
  metrics: Metric[];
  protocolNotes: string;
  simulationIds: SimId[];
  status: Status;
  createdAt: string;
  ownerId?: string;
  sample?: boolean;
}

export type ReviewCategory = "question" | "methodological" | "improvement";
export const CATEGORIES: { id: ReviewCategory; label: string; hint: string; color: string }[] = [
  { id: "question", label: "Question", hint: "Ask for clarification about a result, step or concept.", color: "#06B6D4" },
  { id: "methodological", label: "Methodological Note", hint: "Point out a gap, control or assumption in the method.", color: "#F59E0B" },
  { id: "improvement", label: "Improvement Idea", hint: "Suggest a concrete way to extend or improve the work.", color: "#10B981" },
];

export interface Review {
  id: string;
  targetType: "project" | "simulation";
  targetId: string;
  category: ReviewCategory;
  body: string;
  authorName: string;
  status: Status;
  createdAt: string;
  ownerId?: string;
}

export interface User { id: string; email: string; name: string; isAdmin: boolean }
