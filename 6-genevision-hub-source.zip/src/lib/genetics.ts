export const BASES = ["A", "C", "G", "T"] as const;

const AA_TABLE: Record<string, string> = {};
const bases = "TCAG";
const aas = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG";
let i = 0;
for (const a of bases) for (const b of bases) for (const c of bases) AA_TABLE[a + b + c] = aas[i++];
export const CODON_TABLE = AA_TABLE; // DNA codons (coding strand, T not U)

export const AA_INFO: Record<string, { three: string; name: string }> = {
  A: { three: "Ala", name: "Alanine" }, R: { three: "Arg", name: "Arginine" }, N: { three: "Asn", name: "Asparagine" },
  D: { three: "Asp", name: "Aspartic acid" }, C: { three: "Cys", name: "Cysteine" }, Q: { three: "Gln", name: "Glutamine" },
  E: { three: "Glu", name: "Glutamic acid" }, G: { three: "Gly", name: "Glycine" }, H: { three: "His", name: "Histidine" },
  I: { three: "Ile", name: "Isoleucine" }, L: { three: "Leu", name: "Leucine" }, K: { three: "Lys", name: "Lysine" },
  M: { three: "Met", name: "Methionine" }, F: { three: "Phe", name: "Phenylalanine" }, P: { three: "Pro", name: "Proline" },
  S: { three: "Ser", name: "Serine" }, T: { three: "Thr", name: "Threonine" }, W: { three: "Trp", name: "Tryptophan" },
  Y: { three: "Tyr", name: "Tyrosine" }, V: { three: "Val", name: "Valine" }, "*": { three: "Stop", name: "Stop codon" },
};

const COMP: Record<string, string> = { A: "T", T: "A", G: "C", C: "G" };
export const complement = (s: string) => [...s].map((c) => COMP[c] ?? "N").join("");
export const reverseComplement = (s: string) => complement(s).split("").reverse().join("");
export const cleanDNA = (s: string) => s.toUpperCase().replace(/[^ACGT]/g, "");
export const gcContent = (s: string) => (s.length ? ([...s].filter((c) => c === "G" || c === "C").length / s.length) * 100 : 0);

export function translateDNA(coding: string, startAtAUG = true): { protein: string; start: number; stopped: boolean } {
  const s = coding.toUpperCase();
  let start = 0;
  if (startAtAUG) {
    start = s.indexOf("ATG");
    if (start < 0) return { protein: "", start: -1, stopped: false };
  }
  let protein = "";
  let stopped = false;
  for (let p = start; p + 3 <= s.length; p += 3) {
    const aa = CODON_TABLE[s.slice(p, p + 3)] ?? "X";
    if (aa === "*") { stopped = true; break; }
    protein += aa;
  }
  return { protein, start, stopped };
}

/** Basic melting temperature: Wallace rule (<14 nt) or GC-based formula (>=14 nt). Educational estimate. */
export function primerTm(seq: string): number {
  const n = seq.length;
  if (!n) return 0;
  const gc = [...seq].filter((c) => c === "G" || c === "C").length;
  const at = n - gc;
  if (n < 14) return 2 * at + 4 * gc;
  return 64.9 + (41 * (gc - 16.4)) / n;
}

export const rnaOf = (dna: string) => dna.replace(/T/g, "U");
