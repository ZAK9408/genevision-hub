import { HashRouter, Route, Routes } from "react-router-dom";
import { AppProvider } from "./store/AppContext";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import { SimulationsIndex, SimulationPage } from "./pages/Simulations";
import { Showcase, ProjectDetail, Saved } from "./pages/Showcase";
import Builder from "./pages/Builder";
import Login from "./pages/Login";
import Admin from "./pages/Admin";

export default function App() {
  return (
    <AppProvider>
      <HashRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="simulations" element={<SimulationsIndex />} />
            <Route path="simulations/:id" element={<SimulationPage />} />
            <Route path="showcase" element={<Showcase />} />
            <Route path="project/:id" element={<ProjectDetail />} />
            <Route path="builder" element={<Builder />} />
            <Route path="builder/:id" element={<Builder />} />
            <Route path="saved" element={<Saved />} />
            <Route path="login" element={<Login />} />
            <Route path="admin" element={<Admin />} />
            <Route path="*" element={<Home />} />
          </Route>
        </Routes>
      </HashRouter>
    </AppProvider>
  );
}
