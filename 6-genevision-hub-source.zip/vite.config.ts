import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
// assetsDir "" keeps every built file at one level so the output can be uploaded flat (e.g. through GitHub's web uploader).
export default defineConfig({ base: "./", plugins: [react()], build: { assetsDir: "" } });
