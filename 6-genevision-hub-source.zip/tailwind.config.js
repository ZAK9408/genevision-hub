export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { canvas: "#060911", surface: "#0D1322", line: "#1E293B", cyan: { DEFAULT: "#06B6D4" }, bio: "#10B981", mol: "#8B5CF6", amber: { DEFAULT: "#F59E0B" } },
    fontFamily: { sans: ["Inter", "system-ui", "sans-serif"], mono: ["JetBrains Mono", "ui-monospace", "monospace"] }
  } },
  plugins: []
};
